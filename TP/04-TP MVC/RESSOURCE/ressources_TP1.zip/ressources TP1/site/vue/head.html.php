    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta charset="UTF-8" />
		<meta name="robots" content="noindex" />
		<meta name="googlebot" content="noindex" />  
		<meta name="description" content="" />
		<meta name="author" content="" />
		<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet" />
		<link href="asset/font/awesome/css/font-awesome.min.css" rel="stylesheet" />
		<!-- static local -->
		<link href="asset/css/base.css" rel="stylesheet" />
		<link href="asset/css/form.css" rel="stylesheet" />
		<link href="asset/css/cgu.css" rel="stylesheet" />
		<link href="asset/css/corps.css" rel="stylesheet" />        
        <title><?= $titre ?></title>
    </head>