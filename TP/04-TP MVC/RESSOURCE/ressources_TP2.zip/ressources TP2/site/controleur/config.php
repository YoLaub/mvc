<?php

/**
 * CONFIG GLOBAL 
 */

//Chemin absolu de l'application :
define("RACINE", dirname(__DIR__));

?>
